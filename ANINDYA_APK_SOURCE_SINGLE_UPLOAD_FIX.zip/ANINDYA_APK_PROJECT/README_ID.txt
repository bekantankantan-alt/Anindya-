ANINDYA - PROYEK APK ANDROID

Tujuan:
- Menjalankan launcher ANINDYA dalam Android WebView.
- Kamera tampil langsung pada kotak preview ANINDYA (tidak membuka aplikasi kamera eksternal).
- Kamera belakang/depan, flash/torch bila didukung perangkat, stamp LINE/tanggal/jam/tulisan tambahan.
- Foto disimpan langsung ke Galeri > Pictures/ANINDYA.

CARA BUILD APK DARI HP MELALUI GITHUB
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub.
3. Upload seluruh ISI folder ANINDYA_APK_PROJECT ke repository (bukan folder luarnya).
4. Buka tab Actions di repository.
5. Pilih workflow "Build ANINDYA APK" lalu tekan Run workflow.
6. Tunggu sampai proses selesai (hijau).
7. Buka hasil workflow, bagian Artifacts, unduh "ANINDYA-debug-APK".
8. Ekstrak file artifact dan instal app-debug.apk di HP.

CATATAN KAMERA
- Saat pertama dibuka, izinkan akses kamera.
- Kamera live dirender di elemen video dalam kotak preview di aplikasi ANINDYA.
- APK menggunakan HTTPS WebViewAssetLoader agar getUserMedia berjalan sebagai secure origin.
- Flash/torch hanya dapat menyala bila kamera dan sistem Android mendukung serta tidak dibatasi kondisi perangkat.
- Penyimpanan foto memakai MediaStore ke Pictures/ANINDYA.

BUILD ENVIRONMENT
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35, minSdk 23, targetSdk 35

Ini adalah proyek sumber untuk membangun APK debug melalui GitHub Actions; file APK belum dibangun di sini.

IKON APLIKASI:
Ikon launcher menggunakan PNG transparan yang mempertahankan kontur badge ANINDYA. Pada beberapa launcher Android, sistem dapat tetap menerapkan masking ikon bawaan.
