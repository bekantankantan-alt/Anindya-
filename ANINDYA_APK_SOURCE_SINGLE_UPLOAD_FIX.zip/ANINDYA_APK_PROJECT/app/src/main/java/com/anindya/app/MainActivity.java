package com.anindya.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Color;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends Activity {
 private static final int REQ_CAMERA=71, REQ_FILE=72;
 private WebView webView; private PermissionRequest pendingRequest; private ValueCallback<Uri[]> fileCallback; private WebViewAssetLoader assetLoader;
 @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.rgb(5,12,24));getWindow().setNavigationBarColor(Color.rgb(5,12,24));
  webView=new WebView(this);webView.setBackgroundColor(Color.BLACK);webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE,null);setContentView(webView);
  assetLoader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(true);s.setSupportZoom(false);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);s.setLoadsImagesAutomatically(true);s.setBlockNetworkImage(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  webView.addJavascriptInterface(new GalleryBridge(),"AndroidGallery");
  webView.setWebViewClient(new WebViewClientCompat(){@Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v,android.webkit.WebResourceRequest r){return assetLoader.shouldInterceptRequest(r.getUrl());}});
  webView.setWebChromeClient(new WebChromeClient(){
   @Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->{boolean cam=false;for(String x:r.getResources())if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(x))cam=true;if(cam&&ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else if(cam){pendingRequest=r;ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CAMERA},REQ_CAMERA);}else r.deny();});}
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(Intent.createChooser(i,"Pilih foto"),REQ_FILE);return true;}
  });
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
  webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_FILE&&fileCallback!=null){Uri[] r=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)r=new Uri[]{data.getData()};fileCallback.onReceiveValue(r);fileCallback=null;}}
 @Override public void onRequestPermissionsResult(int code,@NonNull String[] p,@NonNull int[] r){super.onRequestPermissionsResult(code,p,r);if(code==REQ_CAMERA&&pendingRequest!=null){if(r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)pendingRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else{pendingRequest.deny();Toast.makeText(this,"Izin kamera diperlukan untuk kamera di dalam ANINDYA.",Toast.LENGTH_LONG).show();}pendingRequest=null;}}
 private class GalleryBridge{@JavascriptInterface public boolean saveImage(String dataUrl,String filename){try{int comma=dataUrl.indexOf(',');if(comma<0)return false;byte[] bytes;if(Build.VERSION.SDK_INT>=26)bytes=Base64.getDecoder().decode(dataUrl.substring(comma+1));else bytes=android.util.Base64.decode(dataUrl.substring(comma+1),android.util.Base64.DEFAULT);ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,filename);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ANINDYA");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)return false;try(OutputStream o=getContentResolver().openOutputStream(u)){if(o==null)return false;o.write(bytes);o.flush();}return true;}catch(Exception e){return false;}}}
 @Override public void onBackPressed(){if(webView!=null)webView.evaluateJavascript("(function(){var o=document.getElementById('anindyaCamOverlay');if(o&&o.classList.contains('open')){document.getElementById('anindyaCamClose').click();return;}var e=document.getElementById('editFotoOverlay');if(e&&e.classList.contains('open')){e.classList.remove('open');return;}})()",null);else super.onBackPressed();}
 @Override protected void onDestroy(){if(webView!=null){webView.loadUrl("about:blank");webView.destroy();webView=null;}super.onDestroy();}
}
